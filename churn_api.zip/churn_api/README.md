# API de Predição de Churn — CEUB

Implementa a **camada de serviço** e a **rotina mensal de pontuação** descritas no
documento de arquitetura, reaproveitando fielmente a lógica de dados do notebook
`Modelo_Churn_CEUB.ipynb` (carga, limpeza, anonimização LGPD e engenharia de
atributos). O modelo é tratado como um artefato servido, executado e versionado.

## Arquitetura em uma frase

`export mensal` → **rotina batch** (limpeza → anonimização → atributos → pontuação)
→ persiste em **MongoDB** (`predicoes`) → atualiza **Redis** (cache) → consumo pela
**API Flask** e por dashboards de BI.

## Componentes

| Arquivo | Papel |
|---|---|
| `churn_core.py` | Lógica de dados do notebook (limpeza, anonimização LGPD, features anti-vazamento). Fonte única para treino e inferência. |
| `train_model.py` | Treina os 5 algoritmos, escolhe o melhor por ROC-AUC, reajusta na base toda e salva a Pipeline + metadados. |
| `model_service.py` | Carrega o artefato e expõe a inferência (probabilidade + faixa de risco). |
| `batch_scoring.py` | Rotina **mensal** (seção 5 do doc): pontua a base, grava `predicoes`, atualiza o cache e registra `model_runs`. |
| `app.py` | **API Flask** (seção 6 do doc). |
| `storage.py` | Acesso a MongoDB e Redis, com degradação graciosa quando indisponíveis. |
| `config.py` | Configuração via variáveis de ambiente. |
| `gerar_dados_exemplo.py` | Gera um export **sintético** para testar sem o arquivo real (que contém dados pessoais). |

## Início rápido (sem MongoDB/Redis)

```bash
pip install -r requirements.txt

# 1) gera dados sintéticos no formato do export real
python gerar_dados_exemplo.py --alunos 400 --saida exemplo_export.xlsx

# 2) treina e salva o modelo (modelos/churn_model.joblib)
python train_model.py exemplo_export.xlsx

# 3) sobe a API
python app.py            # dev
# gunicorn -w 4 -b 0.0.0.0:8000 app:app   # produção
```

Sem MongoDB/Redis a API funciona em modo degradado: `/predict` e `/health`
operam normalmente; os endpoints que dependem de predições persistidas
(`/aluno/<id>/risco`, `/alto-risco`) respondem `503`. Com os bancos disponíveis,
rode a rotina mensal para popular tudo:

```bash
python batch_scoring.py exemplo_export.xlsx --data-referencia 2026-06
```

## Endpoints

| Método | Rota | Descrição |
|---|---|---|
| GET | `/health` | Saúde do serviço e dependências |
| POST | `/predict` | Calcula o risco para atributos enviados (sem persistir) |
| GET | `/aluno/<id_aluno>/risco` | Risco mais recente (Redis → MongoDB) |
| GET | `/alto-risco?data_referencia=AAAA-MM&limite=N` | Lista priorizada de alto risco |
| POST | `/admin/reload-model` | Recarrega o artefato após retreino |

### Exemplo — `POST /predict`

```bash
curl -X POST http://localhost:8000/predict -H "Content-Type: application/json" -d '{
  "atraso_medio_dias": 12.5, "pct_em_dia": 0.2, "valor_medio": 150.0,
  "n_modalidades": 1, "n_telefones": 1, "modalidade_grupo": "Lutas",
  "plano": "Gold", "recorrencia": "Sim", "forma_pgto": "Cheque", "resp_proprio": 0
}'
# -> {"prob_churn": 0.47, "faixa_risco": "Médio", "modelo_versao": "..."}
```

Campos ausentes são tratados pelos imputers da Pipeline; categorias desconhecidas
são ignoradas pelo One-Hot Encoder.

## Configuração

Copie `.env.example` para `.env` e ajuste. Principais variáveis: `MODEL_PATH`,
`MONGO_URI`, `REDIS_URL`, `LIMIAR_ALTO`/`LIMIAR_MEDIO` (faixas de risco — definidas
para privilegiar o recall sobre quem tende a cancelar) e `API_TOKEN` (se definido,
exige `Authorization: Bearer <token>`).

## Agendamento da rotina mensal

`batch_scoring.py` é um job idempotente por `data_referencia`. Agende-o no início de
cada mês via cron / agendador de nuvem / orquestrador (Airflow, Prefect). Exemplo cron:

```
0 3 1 * *  cd /app && python batch_scoring.py /dados/export_mensal.xls
```

## Privacidade (LGPD)

A anonimização (`churn_core.anonimizar`) ocorre na ingestão, antes de qualquer
persistência: gera `id_aluno` artificial, guarda apenas a contagem de telefones e
descarta nome, telefone, matrícula original e identificação da academia. Nenhuma
coleção persiste dados pessoais; a reidentificação só é possível no sistema de origem.

## Observação

O artefato e o `exemplo_export.xlsx` gerados são **sintéticos**, só para demonstração.
Para produção, treine com o export real (`python train_model.py CAMINHO_REAL.xls`),
que reproduz o resultado do notebook (XGBoost, ROC-AUC ≈ 0,849).
